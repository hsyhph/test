package net.seesharpsoft.intellij.plugins.csv;

import com.intellij.psi.impl.cache.impl.todo.PlainTextTodoIndexer;

public class CsvTodoIndexer extends PlainTextTodoIndexer {
}
