package net.seesharpsoft.intellij.plugins.csv.editor.table.swing;

public abstract class CsvTableEditorUtilBase {

    protected CsvTableEditorSwing csvTableEditor;

    public CsvTableEditorUtilBase(CsvTableEditorSwing csvTableEditorArg) {
        this.csvTableEditor = csvTableEditorArg;
    }
}
