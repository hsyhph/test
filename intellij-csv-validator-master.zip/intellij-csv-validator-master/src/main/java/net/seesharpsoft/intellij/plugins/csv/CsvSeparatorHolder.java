package net.seesharpsoft.intellij.plugins.csv;

public interface CsvSeparatorHolder {
    CsvValueSeparator getSeparator();
}
